/**
 * Contains classes to explore data returned from a SQLCipher database.
 */
package net.sqlcipher;
